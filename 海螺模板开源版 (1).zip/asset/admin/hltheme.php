<?php
return array (
  'theme' => 
  array (
    'logo' => 
    array (
      'bpic' => 'template/conch/asset/img/logo_black.png',
      'wpic' => 'template/conch/asset/img/logo_white.png',
      'icon' => 'template/conch/asset/img/favicon.png',
      'webapp' => 'template/conch/asset/img/ios_fav.png',
    ),
    'lazy' => 'template/conch/asset/img/load.gif',
    'head' => 
    array (
      'text' => '',
    ),
    'foot' => 
    array (
      'text' => '<p>本站只提供WEB页面服务，本站不存储、不制作任何视频，不承担任何由于内容的合法性及健康性所引起的争议和法律责任。</p>
<p>若本站收录内容侵犯了您的权益，请附说明联系邮箱，本站将第一时间处理。</p>',
    ),
    'type' => 
    array (
      'hom' => '1,2,3,4',
      'meunbtn' => '1',
      'meunys' => 'one',
      'meunid' => '1,2,3,4',
      'ht' => '1,2',
      'ho' => '3,4',
      'hb' => '999',
      'zb' => '999',
    ),
    'notice' => 
    array (
      'btn' => '1',
      'text' => '欢迎使用首涂影视模版，官方网站：<span class=\'mycol\'>www.rclou.cn</span>，BUG反馈QQ群：583188776',
    ),
    'hotvod' => 
    array (
      'btn' => '1',
      'title' => '热播推荐',
    ),
    'actor' => 
    array (
      'hbtn' => '0',
      'htitle' => '荧幕热星',
      'title' => '明星',
      'btn' => '0',
    ),
    'rank' => 
    array (
      'hbtn' => '1',
      'hby' => 'week',
      'hid' => '1,2,3,4',
      'vby' => 'week',
      'btn' => '1',
      'title' => '排行榜',
      'num' => '6',
      'id' => '1,2,3,4,6,7',
    ),
    'banner' => 
    array (
      'btn' => '1',
      'ms' => 'small',
      'smbg' => '1',
      'bgstyle' => '',
    ),
    'search' => 
    array (
      'text' => '海量影片精彩看不停',
	  'lxbtn' => '0',
    ),
    'play' => 
    array (
      'height' => '56.25',
      'adbtn' => '1',
      'nbtn' => '1',
      'notice' => '<li><span class=\'mytip\'>提醒</span>不要轻易相信视频中的广告，谨防上当受骗!</li>
<li>如果无法播放请重新刷新页面，或者切换线路。</li>
<li>视频载入速度跟网速有关，请耐心等待几秒钟。</li>',
    ),
    'show' => 
    array (
      'filter' => 'a|b|c|d|e',
    ),
    'playlink' => 
    array (
      'btn' => '0',
    ),
    'nav' => 
    array (
      'id' => '1,2,3,4,5',
      'zdybtn' => '0',
      'zdybtn1' => '1',
      'zdyname1' => '首涂模版',
      'zdylink1' => 'http://www.ishoutu.com',
      'zdypic1' => 'template/conch/asset/img/ios_fav.png',
      'zdybtn2' => '0',
      'zdyname2' => '',
      'zdylink2' => '',
      'zdypic2' => '',
      'zdybtn3' => '0',
      'zdyname3' => '',
      'zdylink3' => '',
      'zdypic3' => '',
      'zdybtn4' => '0',
      'zdyname4' => '',
      'zdylink4' => '',
      'zdypic4' => '',
    ),
    'rtnav' => 
    array (
      'ym' => 'a|c|e|h|i',
      'zdybtn1' => '0',
      'zdyname1' => '',
      'zdylink1' => '',
      'zdybtn2' => '0',
      'zdyname2' => '',
      'zdylink2' => '',
    ),
    'fnav' => 
    array (
      'btn' => '1',
      'id' => '1,2',
      'ym' => 'h|b|g',
      'zdybtn1' => '0',
      'zdyname1' => '',
      'zdylink1' => '',
      'zdybtn2' => '0',
      'zdyname2' => '',
      'zdylink2' => '',
    ),
    'share' => 
    array (
      'bdbtn' => '1',
      'api' => 'sina',
      'link' => '',
      'apiurl' => '',
      'tok' => '',
      'term' => 'long',
    ),
    'qq' => 
    array (
      'btn' => '0',
      'title' => '',
      'link' => '',
    ),
    'weixin' => 
    array (
      'btn' => '1',
      'btntext' => '关注我们，精彩福利看不停',
      'qrcode' => 'template/conch/asset/img/ewm.jpg',
      'title' => '关注微信观看',
      'text' => '<p>长按识别二维码或微信扫码关注</p><p>关注后回复片名即可</p><p>或微信搜索微信名：<span class=\'mycol\'>首涂影视模版</span></p>',
    ),
    'zans' => 
    array (
      'btn' => '1',
      'qrcode' => 'template/conch/asset/img/dsm.jpg',
      'title' => '感谢赞赏',
      'text' => '<p>长按识别二维码或微信扫描二维码</p><p>金额随意，多少都是支持</p>',
    ),
    'apps' => 
    array (
      'btn' => '0',
      'link' => '',
    ),
    'map' => 
    array (
      'btn' => '1',
      'title' => '最近更新',
      'id' => '',
    ),
    'color' => 
    array (
      'select' => '0',
      'sbtn' => '1',
      'ms' => 'white',
      'mbtn' => '1',
    ),
    'topic' => 
    array (
      'title' => '专题',
      'btn' => '1',
    ),
    'role' => 
    array (
      'title' => '角色',
      'btn' => '0',
    ),
    'plot' => 
    array (
      'title' => '分剧情',
      'btn' => '0',
    ),
    'gbook' => 
    array (
      'title' => '留言',
    ),
    'user' => 
    array (
      'title' => '会员',
    ),
    'seos' => 
    array (
      'index_name' => '',
      'index_key' => '',
      'index_des' => '',
      'detail_name' => '',
      'detail_key' => '',
      'detail_des' => '',
      'play_name' => '',
      'play_key' => '',
      'play_des' => '',
      'down_name' => '',
      'down_key' => '',
      'down_des' => '',
      'arti_name' => '',
      'arti_key' => '',
      'arti_des' => '',
      'artd_name' => '',
      'artd_key' => '',
      'artd_des' => '',
      'topic_name' => '',
      'topic_key' => '',
      'topic_des' => '',
      'topicd_name' => '',
      'topicd_key' => '',
      'topicd_des' => '',
    ),
    'ads' => 
    array (
      'bottom' => 
      array (
        'btn' => '0',
        'content' => '',
      ),
      'all' => 
      array (
        'btn' => '0',
        'content' => '',
      ),
      'banner' => 
      array (
        'btn' => '0',
        'tbtn' => '0',
        'title' => '',
        'sub' => '',
        'link' => '',
        'pic' => '',
      ),
      'vod_w' => 
      array (
        'btn' => '0',
        'content' => '',
      ),
      'vod_r' => 
      array (
        'btn' => '0',
        'content' => '',
      ),
      'play' => 
      array (
        'btn' => '0',
        'tbtn' => '0',
        'title' => '',
        'link' => '',
        'pic' => '',
      ),
      'search_v' => 
      array (
        'btn' => '0',
        'tbtn' => '0',
        'title' => '',
        'sub' => '',
        'link' => '',
        'pic' => '',
      ),
      'art_w' => 
      array (
        'btn' => '0',
        'content' => '',
      ),
      'art_r' => 
      array (
        'btn' => '0',
        'content' => '',
      ),
      'artlist' => 
      array (
        'btn' => '0',
        'tbtn' => '0',
        'title' => '',
        'link' => '',
        'pic' => '',
      ),
      'user' => 
      array (
        'btn' => '0',
        'pic' => '',
      ),
    ),
  ),
);